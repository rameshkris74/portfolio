// ---------- Footer year ----------
document.getElementById("year").textContent = new Date().getFullYear();

// ---------- Terminal typing effect ----------
const typeTarget = document.getElementById("typeline");
const fullText = "Ramesh Krishnan S — Frontend Web Developer";
let charIndex = 0;

function typeChar() {
  if (charIndex <= fullText.length) {
    typeTarget.textContent = fullText.slice(0, charIndex);
    charIndex++;
    setTimeout(typeChar, 45);
  }
}

// Respect reduced motion preference
const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
if (prefersReducedMotion) {
  typeTarget.textContent = fullText;
} else {
  typeChar();
}

// ---------- Scroll-reveal for sections ----------
const revealEls = document.querySelectorAll(".skill-card, .project, .about-grid, .fact");
revealEls.forEach((el) => {
  el.style.opacity = "0";
  el.style.transform = "translateY(16px)";
  el.style.transition = "opacity 0.6s ease, transform 0.6s ease";
});

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = "1";
        entry.target.style.transform = "translateY(0)";
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.15 }
);

if (!prefersReducedMotion) {
  revealEls.forEach((el) => observer.observe(el));
} else {
  revealEls.forEach((el) => {
    el.style.opacity = "1";
    el.style.transform = "none";
  });
}

// ---------- Contact form validation ----------
const form = document.getElementById("contactForm");
const status = document.getElementById("formStatus");

function setError(fieldId, errorId, message) {
  const field = document.getElementById(fieldId);
  const errorEl = document.getElementById(errorId);
  field.closest(".field").classList.toggle("has-error", Boolean(message));
  errorEl.textContent = message || "";
}

function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  status.textContent = "";

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();

  let valid = true;

  if (!name) {
    setError("name", "nameError", "Please enter your name.");
    valid = false;
  } else {
    setError("name", "nameError", "");
  }

  if (!email) {
    setError("email", "emailError", "Please enter your email.");
    valid = false;
  } else if (!isValidEmail(email)) {
    setError("email", "emailError", "That email doesn't look right.");
    valid = false;
  } else {
    setError("email", "emailError", "");
  }

  if (!message) {
    setError("message", "messageError", "Please add a short message.");
    valid = false;
  } else {
    setError("message", "messageError", "");
  }

  if (!valid) {
    status.textContent = "Please fix the highlighted fields.";
    status.style.color = "#F2868B";
    return;
  }

  // No backend wired up — this is a static demo form.
  status.style.color = "var(--accent)";
  status.textContent = `Thanks, ${name.split(" ")[0]}! This is a demo form, so nothing was actually sent — but in a live version, your message would land in my inbox.`;
  form.reset();
});
